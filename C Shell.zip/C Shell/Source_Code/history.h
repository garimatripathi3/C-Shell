#ifndef HIS_H
#define HIS_H

#include "args.h"

void History(ArgList* arglist);
void Write_History(char* line);
long long Read_History(char** his_arr);

#endif
