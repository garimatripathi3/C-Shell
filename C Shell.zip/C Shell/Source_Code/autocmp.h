#ifndef AUTOCMP_H
#define AUTOCMP_H

char* Autocomplete(char* line);
void Get_Last_Token(char* line, char* word);
char* Shit_Func(char* old, char* cmplted);

#endif
