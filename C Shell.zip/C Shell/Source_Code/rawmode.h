#ifndef RAW_H
#define RAW_H

void Enable_Raw();
void Disable_Raw();
char* Raw_Inp();

#endif
