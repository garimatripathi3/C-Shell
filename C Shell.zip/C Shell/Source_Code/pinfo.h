#ifndef PINFO_H
#define PINFO_H

#include "args.h"

void Pinfo(ArgList* arglist);

#endif
