#ifndef PROMPT_H
#define PROMPT_H

void Print_Prompt(int type, char* home_dir, int time_taken);
char* Read_Cmd();

#endif
