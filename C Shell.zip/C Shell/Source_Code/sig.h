#ifndef SIG_H
#define SIG_H

#include "args.h"

void Sig(ArgList* arglist);

#endif
