#ifndef ECHO_H
#define ECHO_H

#include "args.h"

void Echo(ArgList* arglist);

#endif
