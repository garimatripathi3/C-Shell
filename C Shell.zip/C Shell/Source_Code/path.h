#ifndef PATH_H
#define PATH_H

#include "args.h"

void Pwd(ArgList* arglist);
void Cd(ArgList* arglist);

#endif
