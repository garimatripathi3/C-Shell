#ifndef PARSE_H
#define PARSE_H

#include "args.h"

void Parse(char* line);
void Parse_Cmd(char* cmd);

#endif
