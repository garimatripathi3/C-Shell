# OSN Assignment: 3 (DotCom - Shell in C)

Name: Garima Tripathi

Operating System Used: Arch Linux x86_64

Kernel Version: 5.19.8-arch1-1

GCC Version: 12.2.0

GNU Make Version: 4.3

## Deployment

Unzip all the contents of zip into a folder.

`cd` into the folder where the `Makefile` is located.

```bash
$ make
```

This will create an executable named `DotCom`. Run this executable to start your shell.

```bash
$ ./DotCom
```

## The Prompt

The prompt is inspired from bash and follows the format given in question:

```bash
<username@sys_name: curr_dir >
```

### Features

The commands are entered after the prompt appears.

- args.c contains the data-structures and functions used to take and store input.

- autocmp.c contains the code for autocompletion.

- discover.c contains the code for `discover` function built into the shell.

- echo.c contains the code for `echo` function built into the shell.

- exec.c contains the functions used for executing the parsed input. It includes functions for pipelining, redirection, foreground and background processes.

- history.c contains the code for `history` function built into the shell.

- jobs.c contains the code for the `jobs` function built into the shell. It also contains functions like Child Handler for child processes.

- ls.c contains the code for the `ls` function built into the shell.

- main.c is the driver code.

- misc.c contains miscellaneous functions which are used as helper functions throughout project.

- parse.c contains the functions to parse the raw input into argument list.

- path.c contains the code for `pwd` and `cd` functions built into the shell.

- pinfo.c contains the code for `pinfo` function built into the shell.

- proc.c contains code for `fg` and `bg` functions built into the shell. It also contains functions used in handling processes and process groups.

- prompt.c contains code for printing prompt.

- rawmode.c contains code for enabling raw-mode and taking input.

- sig.c contains code for `sig` function built into the shell.

---
